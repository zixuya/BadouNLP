


def printvar(varName, var):
    print(f"\n {varName}={var}")
    print(f"\n type({varName})={type(var)}")



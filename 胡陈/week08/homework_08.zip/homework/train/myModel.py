# -*- coding: utf-8 -*-

import torch
import torch.nn as nn
from torch.optim import Adam, SGD
from torch.nn.utils.rnn import pack_padded_sequence, pad_packed_sequence
from Global import printvar
"""
建立网络模型结构
"""

class SentenceEncoder(nn.Module):
    def __init__(self, config):
        super(SentenceEncoder, self).__init__()
        hidden_size = config["hidden_size"]
        # printvar("hidden_size",hidden_size)
        vocab_size = config["vocab_size"] + 1
        # print(f"\n config['vocab_size'] = {config["vocab_size"]}")
        # printvar("vocab_size",vocab_size)

        max_length = config["max_length"]

        self.embedding = nn.Embedding(vocab_size, hidden_size, padding_idx=0)#每个嵌入向量的维度
        # self.layer = nn.LSTM(hidden_size, hidden_size, batch_first=True, bidirectional=True)
        self.layer = nn.Linear(hidden_size, hidden_size)
        self.dropout = nn.Dropout(0.5)#随机丢弃50%的神经元
        self.count=0
        

    #输入为问题字符编码
    def forward(self, x):
        self.count += 1
        # if self.count < 5:
        #     printvar("x.gt(0)",x.gt(0))

        sentence_length = torch.sum(x.gt(0), dim=-1)#gt:grater than #sentence_length 长度为 32
        #dim=-1 按最后一个维度求和。x.gt(0)是32*20的；按1维求和，即列+列  所以是每行的20列相加为一个数据，最后总共得到32行的32个数据。

        # if self.count < 5:
        #     printvar("sentence_length",sentence_length)

        x = self.embedding(x)
        #使用lstm
        # x, _ = self.layer(x)
        #使用线性层
        x = self.layer(x)
        x = nn.functional.max_pool1d(x.transpose(1, 2), x.shape[1]).squeeze()#pooling
        # if self.count < 2:
        #     printvar("pooling result",x)

        return x


class SiameseNetwork(nn.Module):
    def __init__(self, config):
        super(SiameseNetwork, self).__init__()
        self.sentence_encoder = SentenceEncoder(config)
        # print(f"\n type(sentence encoder) = {type(self.sentence_encoder)}")
        # self.loss = nn.CosineEmbeddingLoss()
        self.loss = self.cosine_triplet_loss
        self.count=0

    # 计算余弦距离  1-cos(a,b)
    # cos=1时两个向量相同，余弦距离为0；cos=0时，两个向量正交，余弦距离为1
    def cosine_distance(self, tensor1, tensor2):
        tensor1 = torch.nn.functional.normalize(tensor1, dim=-1)
        tensor2 = torch.nn.functional.normalize(tensor2, dim=-1)
        cosine = torch.sum(torch.mul(tensor1, tensor2), axis=-1)
        return 1 - cosine

    def cosine_triplet_loss(self, a, p, n, margin=None):
        ap = self.cosine_distance(a, p)
        an = self.cosine_distance(a, n)

        if margin is None:
            diff = ap - an + 0.1
        else:
            # diff = ap - an + margin.squeeze()
            diff = ap - an + margin

        print_flag = 0
        for value in diff:
            if value == False:
                print_flag = 1
                
        # if self.count < 4:
        if print_flag == 1:
            printvar("diff", diff)
            printvar("diff.gt(0)", diff.gt(0))
            printvar("diff[diff.gt(0)]", diff[diff.gt(0)])

        return torch.mean(diff[diff.gt(0)])

    #sentence : (batch_size, max_length)
    def forward(self, sentence1, sentence2=None, anchor_sentence=None):
        #同时传入3个句子
        self.count += 1
        if sentence2 is not None and anchor_sentence is not None:
            vector1 = self.sentence_encoder(sentence1) #vec:(batch_size, hidden_size)
            vector2 = self.sentence_encoder(sentence2)
            anchor = self.sentence_encoder(anchor_sentence)

            #如果有anchor，则计算loss
            if anchor_sentence is not None:

                triplet_loss = self.loss(anchor, vector1, vector2, 0.2)

                # if self.count < 4:
                #     printvar("triplet_loss", triplet_loss)

                return triplet_loss
            #如果无标签，计算余弦距离
            else:
                return self.cosine_distance(vector1, vector2)
        #单独传入一个句子时，认为正在使用向量化能力
        else:
            return self.sentence_encoder(sentence1)


def choose_optimizer(config, model):
    optimizer = config["optimizer"]
    learning_rate = config["learning_rate"]
    if optimizer == "adam":
        return Adam(model.parameters(), lr=learning_rate)
    elif optimizer == "sgd":
        return SGD(model.parameters(), lr=learning_rate)


if __name__ == "__main__":
    from myConfig import Config
    Config["vocab_size"] = 10
    Config["max_length"] = 4
    model = SiameseNetwork(Config)
    s1 = torch.LongTensor([[1,2,3,0], [2,2,0,0]])
    s2 = torch.LongTensor([[1,2,3,4], [3,2,3,4]])
    l = torch.LongTensor([[1],[0]])
    y = model(s1, s2, l)
    print(y)
    # print(model.state_dict())
import torch
import os
import random
import os
import numpy as np
import logging
from myModel import SiameseNetwork, choose_optimizer
from myEvaluate import Evaluator
from myConfig import Config
from myLoader import load_data
from Global import printvar

logging.basicConfig(level = logging.INFO, format = '\n %(module)s-%(funcName)s: %(message)s')
logger = logging.getLogger(__name__)

def main(config):
    if not os.path.isdir(config["model_path"]):
        os.mkdir(config["model_path"])
    train_data = load_data(config["train_data_path"], config)
    model = SiameseNetwork(config)

    optimizer = choose_optimizer(config, model)
    evaluator = Evaluator(config, model, logger)
    
    for epoch in range(config["epoch"]):
        epoch += 1
        model.train()
        train_loss = []
        logger.info("第%d轮训练开始" % epoch)
        for index, batch_data in enumerate(train_data):
            optimizer.zero_grad()
            input_id1, input_id2, anchor_id = batch_data   #输入变化时这里需要修改，比如多输入，多输出的情况
            # if index < 1:
            #     printvar("index",index)
            #     printvar("input_id1",input_id1)
            #     printvar("input_id2",input_id2)
            #     printvar("anchor_id",anchor_id)
            #     printvar("labels",labels)

            loss = model(input_id1, input_id2, anchor_id)
            train_loss.append(loss.item())
            if index % int(len(train_data) / 2) == 0:
                logger.info("batch loss %f" % loss)
            loss.backward()
            optimizer.step()
        logger.info("平均loss值: %f" % np.mean(train_loss))
        evaluator.eval(epoch)




if __name__ == "__main__":
    main(Config)

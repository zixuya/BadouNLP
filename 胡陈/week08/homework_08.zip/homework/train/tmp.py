import torch
from Global import printvar





diff = [True,True,True]

diff[2] = False

for value in diff:
    if value  == False:
        print("yes")
# printvar("diff",diff)
# printvar("diff.gt(0)",diff.gt(0))
# printvar("diff[diff.gt(0)]",diff[diff.gt(0)])
# printvar("torch.mean(diff[diff.gt(0)])",torch.mean(diff[diff.gt(0)]))

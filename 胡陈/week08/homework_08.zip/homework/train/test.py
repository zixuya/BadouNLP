
import json


with open('test.json',encoding='utf8') as f:

    for index, line in enumerate(f):
        line =json.loads(line)
        print(line)
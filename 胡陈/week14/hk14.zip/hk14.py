import os
import glob

# file_dir="./Heroes"
# text = []

# with open(file_dir,"r",encoding="utf8") as f:
#     content = f.read()
#     text.append(content)
#     # print(f"content:{content}")
#     print(f"type(content):{type(content)}")
    
#     pass

# print(f"text:{text}")

# text = ""
# tokens = text.encode("utf-8") # raw bytes
# # tokens = list(map(int, tokens)) # convert to a list of integers in range 0..255 for convenience
# tokens = list(map(int, tokens))

class FileLoader():
    def __init__(self, folder_path):
        self.folder_path = folder_path
        self.content_lists = []
        # self.load_file()
        pass

    def load_file(self):
        path = self.folder_path
        for filename in os.listdir(path):
            if filename.endswith(".txt"):
                file_path = os.path.join(path, filename)
                with open(file_path,"r",encoding="utf8") as f:
                    content = f.read()
                    self.content_lists.append(content)
                    # print(f"content:{content}")

        # print(f"self.content_lists:{self.content_lists}")
        return self.content_lists
    
    def get_all_content_as_string(self):#list转换为一个string
        sContent = "\n".join(self.content_lists)
        return sContent
    pass

class BPE():

    def __init__(self, text_string):
        self.vocab_size = 306 #276 # the desired final vocabulary size  超参数：预期的最终词表大小，根据实际情况自己设置，大的词表会需要大的embedding层
        self.text = text_string
        self.tokens = self.text.encode("utf-8")
        self.tokens = list(map(int, self.tokens))
        # self.stats=None
        
        # print(f"\n\nself.tokens = {self.tokens}")
        # self.stats = self.get_stats(self.tokens)
        # print(f"\n\nself.stats = {self.stats}")
        # self.top_pair = max(self.stats, key=self.stats.get)
        # print(f"\n\nself.top_pair = {self.top_pair}")
        # self.tokens2 = self.merge(self.tokens,self.top_pair,256)
        # print(f"\n\nself.tokens2 = {self.tokens2}")
        self.merged_tokens,self.merges = self.merge_all(self.tokens)
        # print(f"\n\nself.merged_tokens = {self.merged_tokens}")
        # print(f"\n\nself.merges = {self.merges}")
        
        # print(f"\n\n tokens length={len(self.tokens)}")
        # print(f" merged_tokens length={len(self.merged_tokens)}")
        # print(f" compression ratio: {len(self.tokens) / len(self.merged_tokens):.2f}X")
        # self.decode_text = self.decode(self.merged_tokens)
        # print(f"\n\nself.decode_text = {self.decode_text}")

        
    def get_stats(self,ids):
        counts = {}
        for pair in zip(ids, ids[1:]): # Pythonic way to iterate consecutive elements
            counts[pair] = counts.get(pair, 0) + 1
        return counts

    def merge(self, ids, pair, idx):
        newids = []
        i = 0
        while i < len(ids):
            # if we are not at the very last position AND the pair matches, replace it
            if i < len(ids) - 1 and ids[i] == pair[0] and ids[i+1] == pair[1]:
                newids.append(idx)
                i += 2
            else:
                newids.append(ids[i])
                i += 1
        return newids
    pass

    def merge_all(self,tokens):
        num_merges = self.vocab_size - 256
        tokens = list(tokens) # copy so we don't destroy the original list
        merges = {} # (int, int) -> int
        for i in range(num_merges):
            stats = self.get_stats(tokens)
            top_pair = max(stats, key=stats.get)
            idx = 256 + i
            # print(f"[{i}]idx={idx}")
            print(f"merging {top_pair} into a new token {idx}")
            tokens = self.merge(tokens, top_pair, idx)
            merges[top_pair] = idx
        return tokens,merges

    def decode(self, ids):
        vocab = {idx: bytes([idx]) for idx in range(256)} #{65:b'a'}
        for (p0, p1), idx in self.merges.items():
            vocab[idx] = vocab[p0] + vocab[p1]
        tokens = b"".join(vocab[idx] for idx in ids)
        text = tokens.decode("utf-8", errors="replace")
        return text


if __name__ == "__main__":
    
    file_dir="./Heroes"
    file_loader = FileLoader(file_dir)
    content_list = file_loader.load_file()
    # for index,content in enumerate(content_list):
    #     print(f"\n-------------------------------------------\n")
    #     print(f"\ncontent:{content}")

    #把每个txt加载到list，一篇一篇进行操作。
    # for content in content_list:
    #     # print(content)
    #     bpe = BEP(content)

    #所有txt加载到一起 merge了前50个top对
    content_all = file_loader.get_all_content_as_string()
    # print(f"content_all = {content_all}")#太长了，需要时再打印
    bpe = BPE(content_all)

    #decode以后的结果，并打印
    bpe.decode_text = bpe.decode(bpe.merged_tokens)
    # print(f"\n\nself.decode_text = {bpe.decode_text}")#太长了，需要时再打印
    
    #bpe前后的长度和压缩率
    print(f"\n\n tokens length={len(bpe.tokens)}")
    print(f" merged_tokens length={len(bpe.merged_tokens)}")
    print(f" compression ratio: {len(bpe.tokens) / len(bpe.merged_tokens):.2f}X\n")
    
    pass

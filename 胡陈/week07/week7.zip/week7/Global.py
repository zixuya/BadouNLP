


def printvar(varname, var):
    print(f"\n {varname} = {var}")
    print(f"\n type({varname})={type(var)}")
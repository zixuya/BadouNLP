
from myConfig import Config
from myLoader import load_data
from myModel import TorchModel, choose_optimizer
from myEvaluate import Evaluator
import os
import logging
import numpy as np
from Global import printvar
import time
# logging.basicConfig(level=logging.INFO, format = '\n %(asctime)s - %(name)s - %(levelname)s - %(message)s')
logging.basicConfig(level=logging.INFO, format = '\n [%(asctime)s %(module)s-%(funcName)s] %(message)s')
logger = logging.getLogger(__name__)


def main(config):
    
    if not os.path.isdir(config["model_path"]):
        os.mkdir(config["model_path"])

    model_type_list = ['lstm','rnn','rcnn','bert']
    # model_type_list = ['rnn','rcnn']
    result_list={}#记录结果：模型-结果
    for model_type in model_type_list:
        config['model_type'] = model_type
        # printvar('config[model_type]', config['model_type'])
        logger.info("模型 %s 开始训练" % model_type)
        train_data = load_data(config["train_data_path"], config)
        model = TorchModel(config)
        optimizer = choose_optimizer(config, model)
        evaluator = Evaluator(config, model, logger)
        result=[]
        start_time = time.perf_counter()#记录时间
        hidden_size = model.get_hidden_size()
        # printvar('hidden_size', hidden_size)
        for epoch in range(config["epoch"]):
            epoch += 1
            model.train
            logger.info("epoch %d begin" % epoch)
            train_loss = []
            for index, batch_data in enumerate(train_data):
                optimizer.zero_grad()
                input_ids, labels = batch_data
                loss = model(input_ids, labels)
                # if index < 3:
                #     printvar('input_ids',input_ids)
                #     printvar('labels',labels)
                loss.backward()
                optimizer.step()#update variables and grad decent

                # if index < 3:
                #     printvar('loss',loss)
                #     printvar('loss.item()', loss.item())
                
                train_loss.append(loss.item())

                # if index % int(len(train_data) / 2) == 0:
                #         logger.info("batch loss %f" % loss)
            
            logger.info("epoch average loss: %f" % np.mean(train_loss))
            acc = evaluator.eval(epoch)
            # printvar('acc',acc)
        end_lr = optimizer.param_groups[0]['lr']
        end_time = time.perf_counter()#结束时间
        duration = end_time - start_time#耗时
        # printvar('duration',duration)
        # logger.info("模型 %s 正确率：%f" % (model_type, acc))
        # logger.info("模型 %s 最终学习率：%f" % (model_type, end_lr))
        # logger.info("模型 %s 耗时：%f" % (model_type, duration))
        # logger.info("模型 %s hidden_size：%d" % (model_type, hidden_size))
        result.append(acc)
        result.append(end_lr)
        result.append(duration)
        result.append(hidden_size)
        result_list[model_type]=result
        logger.info("模型 %s 训练完成" % model_type)
        # printvar('result_list',result_list)
        print('\n')
    return result_list

if __name__ == "__main__":
    result_list = main(Config)
    # printvar('result',result)
    print('\n\n 训练结果：')
    for model in result_list:
        result = result_list[model]
        print(f"\n 模型:{model} 正确率:{result[0]} 最终学习率:{result[1]} 耗时:{result[2]} hidden_size:{result[3]}")


# with open('original_data.csv',mode='r',encoding='utf-8') as file:
#     # content = csv.reader(file,delimiter='n')
#     content = csv.reader(file,delimiter=',')
#     for i,sentence in enumerate(content):
#         # if i < 10:
#         #     print(sentence)


import json
import re
import os
import torch
import numpy as np
from torch.utils.data import Dataset, DataLoader
from transformers import BertTokenizer
import csv
"""
数据加载
"""

class DataGenerator(Dataset):
    def __init__(self, data_path, config):
        self.config = config
        self.path = data_path
        # self.index_to_label = {0: '好评', 1: '差评'}
        # self.label_to_index = dict((y, x) for x, y in self.index_to_label.items())
        # self.config["class_num"] = len(self.index_to_label)
        self.config["class_num"] = 2
        if self.config["model_type"] == "bert":
            self.tokenizer = BertTokenizer.from_pretrained(config["pretrain_model_path"])
        self.vocab = load_vocab(config["vocab_path"])
        self.config["vocab_size"] = len(self.vocab)
        self.load()

# with open('original_data.csv',mode='r',encoding='utf-8') as file:
#     # content = csv.reader(file,delimiter='n')
#     content = csv.reader(file,delimiter=',')
#     for i,sentence in enumerate(content):
#         # if i < 10:
#         #     print(sentence)

    def load(self):
        self.data = []
        with open(self.path, encoding="utf8") as file:
            # print(f"file name = {self.path}")
            content = csv.reader(file, delimiter=',')
            for i, line in enumerate(content):
                # line = json.loads(line)
                # tag = line["tag"]
                # label = self.label_to_index[tag]
                # title = line["title"]

                label = int(line[0])
                review = line[1]

                # if i < 3:
                    # print(f"Line={line}")
                    # print(f"label={label}")
                    # print(f"review={review}")

                if self.config["model_type"] == "bert":
                    input_id = self.tokenizer.encode(review, max_length=self.config["max_length"], pad_to_max_length=True) # padding='max_length'  pad_to_max_length=True
                else:
                    input_id = self.encode_sentence(review)
                input_id = torch.LongTensor(input_id)

                # if i < 3:
                #     print(f"\nlabel={label}")
                #     print(f"\ntype(label):{type(label)}\n")
                    
                label_index = torch.LongTensor([label])
                # if i < 3:
                #     print(f"\nlabel_index={label_index}")

                one_data = [input_id, label_index]
                # if i < 3:
                #     print(f"\none_data={one_data}")

                self.data.append(one_data)
        return 

    def encode_sentence(self, text):
        input_id = []
        for char in text:
            input_id.append(self.vocab.get(char, self.vocab["[UNK]"]))
        input_id = self.padding(input_id)
        return input_id

    #补齐或截断输入的序列，使其可以在一个batch内运算
    def padding(self, input_id):
        input_id = input_id[:self.config["max_length"]]
        input_id += [0] * (self.config["max_length"] - len(input_id))
        return input_id

    def __len__(self):
        return len(self.data)

    def __getitem__(self, index):
        return self.data[index]

def load_vocab(vocab_path):
    token_dict = {}
    with open(vocab_path, encoding="utf8") as f:
        for index, line in enumerate(f):
            token = line.strip()
            token_dict[token] = index + 1  #0留给padding位置，所以从1开始
    return token_dict


#用torch自带的DataLoader类封装数据
def load_data(data_path, config, shuffle=True):
    dg = DataGenerator(data_path, config)
    dl = DataLoader(dg, batch_size=config["batch_size"], shuffle=shuffle)
    # print(f"\n type({dl})={type(dl)}")
    return dl

if __name__ == "__main__":
    from myConfig import Config
    dg = DataGenerator("original_data.csv", Config)
    dl = DataLoader(dg, batch_size=Config["batch_size"], shuffle=True)
    # print(f"\n type({dl})={type(dl)}")
    # for index, data in enumerate(dl):
    #     if index < 3:
    #         print(f"\n data = {data}")
    # print(dg[1])
